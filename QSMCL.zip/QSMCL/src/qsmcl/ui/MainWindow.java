package qsmcl.ui;

import qsmcl.core.Account;
import qsmcl.core.Fabric;
import qsmcl.core.Launcher;
import qsmcl.core.Modrinth;
import qsmcl.core.Rules;
import qsmcl.core.Settings;
import qsmcl.core.VersionInstaller;
import qsmcl.core.VersionManifest;
import qsmcl.core.VersionMerger;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** QSMCL 主窗口（纯 Swing 现代化 UI，无第三方依赖）。 */
public final class MainWindow extends JFrame {
    // ---------- 主题 ----------
    private static final Color BG      = new Color(0xF3, 0xF4, 0xF9);
    private static final Color CARD    = Color.WHITE;
    private static final Color TEXT    = new Color(0x2A, 0x2F, 0x3A);
    private static final Color SUBTLE  = new Color(0x8A, 0x91, 0xA3);
    private static final Color LINE    = new Color(0xE8, 0xEB, 0xF2);
    private static final Color CONSOLE = new Color(0x17, 0x1A, 0x21);

    private final Path launcherRoot;
    private final Settings settings;

    private JTextField accountField;
    private JComboBox<String> versionCombo;
    private JButton launchButton;
    private JButton downloadButton;
    private JProgressBar progressBar;
    private JLabel statusLabel;
    private JTextArea logArea;
    private JList<VersionManifest.Entry> remoteList;
    private JComboBox<String> filterCombo;
    private DefaultListModel<VersionManifest.Entry> remoteModel;

    // Fabric 安装
    private JComboBox<String> fabricGameCombo;
    private JComboBox<Fabric.Loader> fabricLoaderCombo;
    private JButton fabricButton;

    // 模组页
    private RoundTextField modSearchField;
    private JButton modSearchButton;
    private JList<Modrinth.Mod> modList;
    private DefaultListModel<Modrinth.Mod> modModel;
    private JButton modDownloadButton;
    private JLabel modTargetLabel;

    // 设置页控件
    private JTextField gameDirField, versionsDirField, javaPathField;
    private JSpinner minMemSpin, maxMemSpin, widthSpin, heightSpin;
    private JTextField jvmArgsField;

    // 导航
    private final CardLayout cardLayout = new CardLayout();
    private JPanel cards;
    private final List<NavButton> navButtons = new ArrayList<>();

    public MainWindow(Path launcherRoot, Settings settings) {
        this.launcherRoot = launcherRoot;
        this.settings = settings;
        setTitle("QSMCL — Minecraft 启动器");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(960, 640);
        setMinimumSize(new Dimension(820, 560));
        setLocationRelativeTo(null);
        setIconImages(Icons.windowIcons());
        setContentPane(buildUi());
        loadSettingsToUi();
        refreshLocalVersions();
        refreshRemoteVersions();
    }

    // ================= 整体布局 =================

    private JComponent buildUi() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG);
        root.add(buildHeader(), BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(BG);
        center.add(buildSidebar(), BorderLayout.WEST);

        cards = new JPanel(cardLayout);
        cards.setBackground(BG);
        cards.setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));
        cards.add(card(buildDownloadTab()), "download");
        cards.add(card(buildModsTab()), "mods");
        cards.add(card(buildSettingsTab()), "settings");
        cards.add(card(buildLogTab()), "log");
        center.add(cards, BorderLayout.CENTER);

        root.add(center, BorderLayout.CENTER);
        root.add(buildStatusBar(), BorderLayout.SOUTH);
        switchTo("download"); // 默认选中（cards 已创建完毕）
        return root;
    }

    /** 渐变头部：Logo + 标题 + 玩家名 + 版本 + 启动按钮 */
    private JComponent buildHeader() {
        JPanel h = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setPaint(new GradientPaint(0, 0, Icons.ACCENT, getWidth(), getHeight(), Icons.ACCENT2));
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        h.setPreferredSize(new Dimension(0, 104));
        h.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));

        // 左：Logo + 标题
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 0));
        left.setOpaque(false);
        left.add(new JLabel(new ImageIcon(Icons.logoImage(48))));
        JPanel title = new JPanel();
        title.setOpaque(false);
        title.setLayout(new BoxLayout(title, BoxLayout.Y_AXIS));
        JLabel name = new JLabel("QSMCL");
        name.setFont(new Font("微软雅黑", Font.BOLD, 22));
        name.setForeground(Color.WHITE);
        JLabel sub = new JLabel("轻量级 Minecraft 启动器");
        sub.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        sub.setForeground(new Color(255, 255, 255, 190));
        title.add(name);
        title.add(sub);
        left.add(title);

        // 右：玩家名 + 版本 + 启动
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        right.setOpaque(false);
        accountField = new RoundTextField(10);
        accountField.setToolTipText("离线玩家名");
        accountField.setPreferredSize(new Dimension(130, 36));
        versionCombo = new JComboBox<>();
        versionCombo.setPreferredSize(new Dimension(190, 36));
        versionCombo.setToolTipText("本地版本");
        launchButton = new PillButton("启动游戏");
        ((PillButton) launchButton).setAccentForeground(true);
        launchButton.addActionListener(e -> onLaunch());
        right.add(accountField);
        right.add(versionCombo);
        right.add(launchButton);

        h.add(left, BorderLayout.WEST);
        h.add(right, BorderLayout.EAST);
        return h;
    }

    /** 左侧导航栏 */
    private JComponent buildSidebar() {
        JPanel side = new JPanel();
        side.setBackground(CARD);
        side.setPreferredSize(new Dimension(180, 0));
        side.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, LINE));
        side.setLayout(new BoxLayout(side, BoxLayout.Y_AXIS));
        side.add(Box.createVerticalStrut(18));

        NavButton b1 = new NavButton("download", "版本下载");
        NavButton b2 = new NavButton("mods", "模组下载");
        NavButton b3 = new NavButton("settings", "启动设置");
        NavButton b4 = new NavButton("log", "游戏日志");
        navButtons.addAll(List.of(b1, b2, b3, b4));
        for (NavButton b : navButtons) {
            side.add(b);
            side.add(Box.createVerticalStrut(6));
        }
        side.add(Box.createVerticalGlue());
        JLabel ver = new JLabel("QSMCL 1.0 · 纯手搓");
        ver.setFont(new Font("微软雅黑", Font.PLAIN, 11));
        ver.setForeground(SUBTLE);
        ver.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));
        ver.setAlignmentX(Component.LEFT_ALIGNMENT);
        side.add(ver);
        side.add(Box.createVerticalStrut(16));
        return side;
    }

    /** 底部状态栏 */
    private JComponent buildStatusBar() {
        JPanel bar = new JPanel(new BorderLayout(10, 0));
        bar.setBackground(CARD);
        bar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, LINE),
                BorderFactory.createEmptyBorder(8, 16, 8, 16)));
        statusLabel = new JLabel("就绪");
        statusLabel.setForeground(SUBTLE);
        progressBar = new JProgressBar(0, 100) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int h = getHeight(), w = getWidth();
                int barH = 10;
                int y = (h - barH) / 2 - 4;
                g2.setColor(new Color(0xE9, 0xEB, 0xF2));
                g2.fillRoundRect(0, y, w, barH, barH, barH);
                int fw = (int) (w * getPercentComplete());
                if (fw > barH) {
                    g2.setPaint(new GradientPaint(0, 0, Icons.ACCENT, w, 0, Icons.ACCENT2));
                    g2.fillRoundRect(0, y, Math.min(fw, w), barH, barH, barH);
                }
                String s = getString();
                if (s != null && !s.isBlank()) {
                    g2.setFont(new Font("微软雅黑", Font.PLAIN, 11));
                    g2.setColor(SUBTLE);
                    int tw = g2.getFontMetrics().stringWidth(s);
                    g2.drawString(s, w - tw, y + barH + 2);
                }
            }
        };
        progressBar.setOpaque(false);
        progressBar.setStringPainted(true);
        progressBar.setPreferredSize(new Dimension(280, 26));
        bar.add(statusLabel, BorderLayout.WEST);
        bar.add(progressBar, BorderLayout.EAST);
        return bar;
    }

    /** 白色圆角卡片容器 */
    private JComponent card(JComponent inner) {
        JPanel c = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 18, 18);
                g2.setColor(LINE);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 18, 18);
            }
        };
        c.setOpaque(false);
        inner.setOpaque(false);
        inner.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));
        c.add(inner, BorderLayout.CENTER);
        return c;
    }

    // ================= 三个功能页 =================

    private JComponent buildDownloadTab() {
        remoteModel = new DefaultListModel<>();
        remoteList = new JList<>(remoteModel);
        remoteList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        remoteList.setOpaque(false);
        remoteList.setFixedCellHeight(44);
        remoteList.setSelectionBackground(new Color(0, 0, 0, 0));
        remoteList.setCellRenderer(new DefaultListCellRenderer() {
            private boolean selected;
            {
                setOpaque(false);
                setBorder(BorderFactory.createEmptyBorder(0, 14, 0, 14));
                setFont(new Font("微软雅黑", Font.PLAIN, 13));
            }
            @Override public Component getListCellRendererComponent(JList<?> list, Object value,
                                                                    int index, boolean sel, boolean focus) {
                super.getListCellRendererComponent(list, value, index, sel, focus);
                setForeground(TEXT);
                if (value instanceof VersionManifest.Entry e) {
                    setText("<html><table width=\"100%\"><tr><td>" + e.id()
                            + "</td><td align='right'>" + badgeHtml(e) + "</td></tr></table></html>");
                }
                selected = sel;
                return this;
            }
            @Override protected void paintComponent(Graphics g) {
                if (selected) {
                    Graphics2D g2 = (Graphics2D) g;
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(new Color(0x5B, 0x6C, 0xFF, 0x1E));
                    g2.fillRoundRect(2, 4, getWidth() - 4, getHeight() - 8, 12, 12);
                }
                super.paintComponent(g);
            }
        });
        filterCombo = new JComboBox<>(new String[]{"正式版", "快照版", "全部"});
        filterCombo.addActionListener(e -> applyFilter());
        downloadButton = new AccentButton("下载 / 修复选中版本");
        downloadButton.addActionListener(e -> onDownload());

        JPanel p = new JPanel(new BorderLayout(10, 10));
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        top.setOpaque(false);
        top.add(new JLabel("筛选:"));
        top.add(filterCombo);
        top.add(Box.createHorizontalStrut(8));
        top.add(downloadButton);

        // Fabric 安装行
        fabricGameCombo = new JComboBox<>();
        fabricGameCombo.setToolTipText("原版 MC 版本");
        fabricLoaderCombo = new JComboBox<>();
        fabricLoaderCombo.setToolTipText("Fabric Loader 版本");
        fabricButton = new AccentButton("安装 Fabric 版本");
        fabricButton.addActionListener(e -> onInstallFabric());
        JPanel fabricRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        fabricRow.setOpaque(false);
        fabricRow.add(new JLabel("Fabric:"));
        fabricRow.add(fabricGameCombo);
        fabricRow.add(fabricLoaderCombo);
        fabricRow.add(fabricButton);

        JPanel header = new JPanel();
        header.setOpaque(false);
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.add(top);
        header.add(Box.createVerticalStrut(8));
        header.add(fabricRow);

        p.add(header, BorderLayout.NORTH);
        JScrollPane sp = new JScrollPane(remoteList);
        sp.setOpaque(false);
        sp.getViewport().setOpaque(false);
        sp.setBorder(BorderFactory.createEmptyBorder());
        p.add(sp, BorderLayout.CENTER);
        return p;
    }

    // ================= 模组下载页 =================

    private JComponent buildModsTab() {
        modSearchField = new RoundTextField(20);
        modSearchField.setToolTipText("搜索 Modrinth 模组（英文关键词效果更好）");
        modSearchField.addActionListener(e -> onSearchMods());
        modSearchButton = new AccentButton("搜索");
        modSearchButton.addActionListener(e -> onSearchMods());

        modModel = new DefaultListModel<>();
        modList = new JList<>(modModel);
        modList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        modList.setOpaque(false);
        modList.setFixedCellHeight(56);
        modList.setSelectionBackground(new Color(0, 0, 0, 0));
        modList.setCellRenderer(new DefaultListCellRenderer() {
            private boolean selected;
            {
                setOpaque(false);
                setBorder(BorderFactory.createEmptyBorder(0, 14, 0, 14));
                setFont(new Font("微软雅黑", Font.PLAIN, 13));
            }
            @Override public Component getListCellRendererComponent(JList<?> list, Object value,
                                                                    int index, boolean sel, boolean focus) {
                super.getListCellRendererComponent(list, value, index, sel, focus);
                if (value instanceof Modrinth.Mod m) {
                    String desc = m.description() == null ? "" : m.description();
                    if (desc.length() > 70) desc = desc.substring(0, 70) + "…";
                    setText("<html><b>" + m.title() + "</b>"
                            + " &nbsp;<font color='#8A91A3' size='3'>by " + m.author()
                            + " · " + formatDownloads(m.downloads()) + " 次下载</font><br>"
                            + "<font color='#8A91A3' size='3'>" + desc + "</font></html>");
                }
                selected = sel;
                return this;
            }
            @Override protected void paintComponent(Graphics g) {
                if (selected) {
                    Graphics2D g2 = (Graphics2D) g;
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(new Color(0x5B, 0x6C, 0xFF, 0x1E));
                    g2.fillRoundRect(2, 4, getWidth() - 4, getHeight() - 8, 12, 12);
                }
                super.paintComponent(g);
            }
        });

        modDownloadButton = new AccentButton("下载选中模组到 mods 目录");
        modDownloadButton.addActionListener(e -> onDownloadMod());
        modTargetLabel = new JLabel("");
        modTargetLabel.setForeground(SUBTLE);

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        top.setOpaque(false);
        top.add(modSearchField);
        top.add(modSearchButton);
        top.add(Box.createHorizontalStrut(10));
        top.add(modTargetLabel);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        bottom.setOpaque(false);
        bottom.add(modDownloadButton);

        JScrollPane sp = new JScrollPane(modList);
        sp.setOpaque(false);
        sp.getViewport().setOpaque(false);
        sp.setBorder(BorderFactory.createEmptyBorder());

        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.add(top, BorderLayout.NORTH);
        p.add(sp, BorderLayout.CENTER);
        p.add(bottom, BorderLayout.SOUTH);
        return p;
    }

    private String formatDownloads(long n) {
        if (n >= 100_000_000) return (n / 100_000_000) + " 亿";
        if (n >= 10_000) return (n / 10_000) + " 万";
        return String.valueOf(n);
    }

    private String badgeHtml(VersionManifest.Entry e) {
        String color = e.isRelease() ? "#15803D" : e.isSnapshot() ? "#B45309" : "#6B7280";
        return "<font color='" + color + "'>● " + typeName(e) + "</font>";
    }

    private String typeName(VersionManifest.Entry e) {
        return e.isRelease() ? "正式版" : e.isSnapshot() ? "快照" : e.type();
    }

    private JComponent buildSettingsTab() {
        gameDirField = new RoundTextField(28);
        versionsDirField = new RoundTextField(28);
        javaPathField = new RoundTextField(28);
        jvmArgsField = new RoundTextField(28);
        minMemSpin = new JSpinner(new SpinnerNumberModel(512, 128, 65536, 128));
        maxMemSpin = new JSpinner(new SpinnerNumberModel(4096, 256, 65536, 256));
        widthSpin = new JSpinner(new SpinnerNumberModel(0, 0, 7680, 10));
        heightSpin = new JSpinner(new SpinnerNumberModel(0, 0, 4320, 10));

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 8, 6, 8);
        g.anchor = GridBagConstraints.WEST;
        int row = 0;

        row = addFormRow(form, row, "游戏目录 (.minecraft)", gameDirField, e -> pickDir(gameDirField));
        row = addFormRow(form, row, "版本存放目录 (可跨盘)", versionsDirField, e -> pickDir(versionsDirField));
        row = addFormRow(form, row, "Java 路径 (java.exe)", javaPathField, e -> pickFile(javaPathField));

        // 内存
        g.gridx = 0; g.gridy = row; g.weightx = 0; g.fill = GridBagConstraints.NONE;
        form.add(label("内存 最小/最大 (MB):"), g);
        g.gridx = 1; g.weightx = 1; g.fill = GridBagConstraints.HORIZONTAL;
        JPanel mem = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        mem.setOpaque(false);
        mem.add(minMemSpin);
        mem.add(new JLabel("~"));
        mem.add(maxMemSpin);
        form.add(mem, g);
        row++;

        // 分辨率
        g.gridx = 0; g.gridy = row; g.fill = GridBagConstraints.NONE;
        form.add(label("游戏窗口 宽 x 高 (0=默认):"), g);
        g.gridx = 1; g.fill = GridBagConstraints.HORIZONTAL;
        JPanel res = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        res.setOpaque(false);
        res.add(widthSpin);
        res.add(new JLabel("x"));
        res.add(heightSpin);
        form.add(res, g);
        row++;

        // JVM 参数
        g.gridx = 0; g.gridy = row; g.fill = GridBagConstraints.NONE;
        form.add(label("额外 JVM 参数:"), g);
        g.gridx = 1; g.fill = GridBagConstraints.HORIZONTAL;
        form.add(jvmArgsField, g);
        row++;

        // 保存按钮
        g.gridx = 1; g.gridy = row; g.fill = GridBagConstraints.NONE;
        g.insets = new Insets(16, 8, 6, 8);
        JButton save = new AccentButton("保存设置");
        save.addActionListener(e -> onSaveSettings());
        form.add(save, g);

        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);
        p.add(form, BorderLayout.NORTH);
        return p;
    }

    private int addFormRow(JPanel form, int row, String text, JTextField field,
                           java.awt.event.ActionListener l) {
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 8, 6, 8);
        g.anchor = GridBagConstraints.WEST;
        g.gridx = 0; g.gridy = row; g.weightx = 0; g.fill = GridBagConstraints.NONE;
        form.add(label(text + ":"), g);
        g.gridx = 1; g.weightx = 1; g.fill = GridBagConstraints.HORIZONTAL;
        form.add(field, g);
        g.gridx = 2; g.weightx = 0; g.fill = GridBagConstraints.NONE;
        JButton browse = new GhostButton("浏览...");
        browse.addActionListener(l);
        form.add(browse, g);
        return row + 1;
    }

    private JLabel label(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(TEXT);
        return l;
    }

    private JComponent buildLogTab() {
        logArea = new JTextArea();
        logArea.setEditable(false);
        logArea.setBackground(CONSOLE);
        logArea.setForeground(new Color(0xC9, 0xD1, 0xD9));
        logArea.setCaretColor(new Color(0xC9, 0xD1, 0xD9));
        logArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        logArea.setBorder(BorderFactory.createEmptyBorder(12, 14, 12, 14));
        JScrollPane sp = new JScrollPane(logArea);
        sp.setBorder(BorderFactory.createEmptyBorder());
        sp.getViewport().setBackground(CONSOLE);
        sp.setOpaque(false);
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);
        p.add(sp, BorderLayout.CENTER);
        return p;
    }

    private void pickDir(JTextField field) {
        JFileChooser fc = new JFileChooser();
        fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
            field.setText(fc.getSelectedFile().getAbsolutePath());
    }

    private void pickFile(JTextField field) {
        JFileChooser fc = new JFileChooser();
        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
            field.setText(fc.getSelectedFile().getAbsolutePath());
    }

    // ================= 设置读写 =================

    private void loadSettingsToUi() {
        accountField.setText(settings.lastAccount);
        gameDirField.setText(settings.gameDir);
        versionsDirField.setText(settings.versionsDir);
        javaPathField.setText(settings.javaPath);
        minMemSpin.setValue(settings.minMem);
        maxMemSpin.setValue(settings.maxMem);
        widthSpin.setValue(settings.width);
        heightSpin.setValue(settings.height);
        jvmArgsField.setText(settings.extraJvmArgs);
    }

    private void onSaveSettings() {
        saveSettingsFromUi();
        statusLabel.setText("设置已保存");
        refreshLocalVersions();
    }

    private void saveSettingsFromUi() {
        settings.lastAccount = accountField.getText().trim();
        settings.gameDir = gameDirField.getText().trim();
        settings.versionsDir = versionsDirField.getText().trim();
        settings.javaPath = javaPathField.getText().trim();
        settings.minMem = (int) minMemSpin.getValue();
        settings.maxMem = (int) maxMemSpin.getValue();
        settings.width = (int) widthSpin.getValue();
        settings.height = (int) heightSpin.getValue();
        settings.extraJvmArgs = jvmArgsField.getText().trim();
        settings.save();
    }

    private Path gameDir() {
        saveSettingsFromUi();
        return settings.gameDirectory(launcherRoot);
    }

    /** 解析后的版本存放目录 */
    private Path versionsDir() {
        saveSettingsFromUi();
        return settings.versionsDirectory(settings.gameDirectory(launcherRoot));
    }

    // ================= 版本列表 =================

    private void refreshLocalVersions() {
        versionCombo.removeAllItems();
        Path versionsDir = versionsDir();
        if (Files.isDirectory(versionsDir)) {
            try (var stream = Files.list(versionsDir)) {
                List<Path> dirs = new ArrayList<>(stream.filter(Files::isDirectory).sorted().toList());
                for (Path d : dirs) {
                    Path json = d.resolve(d.getFileName() + ".json");
                    if (Files.isRegularFile(json)) versionCombo.addItem(d.getFileName().toString());
                }
            } catch (IOException ignored) {
            }
        }
        updateModTarget();
    }

    private List<VersionManifest.Entry> allRemote = List.of();

    private void refreshRemoteVersions() {
        remoteModel.clear();
        statusLabel.setText("正在获取版本清单...");
        new SwingWorker<List<VersionManifest.Entry>, Void>() {
            @Override protected List<VersionManifest.Entry> doInBackground() throws Exception {
                return VersionManifest.fetch();
            }
            @Override protected void done() {
                try {
                    allRemote = get();
                    applyFilter();
                    // Fabric 下拉：正式版列表
                    for (VersionManifest.Entry e : allRemote) {
                        if (e.isRelease()) fabricGameCombo.addItem(e.id());
                    }
                    statusLabel.setText("版本清单已加载（共 " + allRemote.size() + " 个版本）");
                } catch (Exception e) {
                    statusLabel.setText("获取版本清单失败: " + e.getMessage());
                }
            }
        }.execute();
        refreshFabricLoaders();
    }

    private void applyFilter() {
        remoteModel.clear();
        String f = String.valueOf(filterCombo.getSelectedItem());
        for (VersionManifest.Entry e : allRemote) {
            if ("正式版".equals(f) && !e.isRelease()) continue;
            if ("快照版".equals(f) && !e.isSnapshot()) continue;
            remoteModel.addElement(e);
        }
    }

    /** 统一的下载进度适配器（UI 线程安全） */
    private VersionInstaller.Progress uiProgress() {
        return new VersionInstaller.Progress() {
            @Override public void stage(String name) {
                SwingUtilities.invokeLater(() -> statusLabel.setText(name));
            }
            @Override public void progress(int done, int total) {
                SwingUtilities.invokeLater(() -> {
                    progressBar.setMaximum(Math.max(total, 1));
                    progressBar.setValue(done);
                    progressBar.setString(done + " / " + Math.max(total, 1));
                });
            }
            @Override public void log(String msg) {
                appendLog(msg);
            }
        };
    }

    // ================= Fabric =================

    private void refreshFabricLoaders() {
        new SwingWorker<List<Fabric.Loader>, Void>() {
            @Override protected List<Fabric.Loader> doInBackground() throws Exception {
                return Fabric.fetchLoaders();
            }
            @Override protected void done() {
                try {
                    int n = 0;
                    for (Fabric.Loader l : get()) {
                        if (n++ >= 15) break; // 只展示最近 15 个版本
                        fabricLoaderCombo.addItem(l);
                    }
                } catch (Exception e) {
                    statusLabel.setText("获取 Fabric 版本列表失败: " + e.getMessage());
                }
            }
        }.execute();
    }

    private void onInstallFabric() {
        String game = (String) fabricGameCombo.getSelectedItem();
        Fabric.Loader loader = (Fabric.Loader) fabricLoaderCombo.getSelectedItem();
        if (game == null || loader == null) {
            JOptionPane.showMessageDialog(this, "请选择原版 MC 版本与 Fabric Loader 版本");
            return;
        }
        VersionManifest.Entry parent = null;
        for (VersionManifest.Entry e : allRemote) {
            if (e.id().equals(game)) { parent = e; break; }
        }
        VersionManifest.Entry finalParent = parent;
        Path gd = gameDir();
        Path vd = versionsDir();
        VersionInstaller.Progress p = uiProgress();
        setBusy(true, "安装 Fabric " + loader.version() + " @ " + game + " ...");
        new SwingWorker<String, Void>() {
            @Override protected String doInBackground() {
                try {
                    return Fabric.install(gd, vd, game, loader.version(), finalParent, p);
                } catch (Exception e) {
                    appendLog("[错误] Fabric 安装失败: " + e);
                    return null;
                }
            }
            @Override protected void done() {
                setBusy(false, "Fabric 版本就绪");
                try {
                    String newId = get();
                    if (newId != null) {
                        refreshLocalVersions();
                        versionCombo.setSelectedItem(newId);
                        statusLabel.setText("已安装: " + newId);
                    } else {
                        statusLabel.setText("Fabric 安装失败，详见日志页");
                    }
                } catch (Exception ignored) {
                }
            }
        }.execute();
    }

    // ================= 模组 =================

    /** 根据当前选中的本地版本推断目标 MC 版本与加载器 */
    private String[] detectTarget() {
        String vid = (String) versionCombo.getSelectedItem();
        if (vid == null) return new String[]{null, null};
        try {
            Map<String, Object> raw = VersionMerger.loadRaw(versionsDir(), vid);
            String parent = Rules.str(raw.get("inheritsFrom"));
            String mc = parent != null ? parent : vid;
            String main = Rules.str(raw.get("mainClass"));
            String loader = (main != null && main.toLowerCase().contains("fabric"))
                    || vid.toLowerCase().contains("fabric") ? "fabric" : null;
            return new String[]{mc, loader};
        } catch (Exception e) {
            return new String[]{vid, null};
        }
    }

    private void updateModTarget() {
        String[] t = detectTarget();
        if (t[0] == null) {
            modTargetLabel.setText("未检测到本地版本，请先安装");
            return;
        }
        modTargetLabel.setText("目标: MC " + t[0] + " · " + (t[1] == null ? "原版" : "Fabric")
                + " · 保存到 " + settings.gameDirectory(launcherRoot).resolve("mods"));
    }

    private void onSearchMods() {
        String query = modSearchField.getText().trim();
        if (query.isEmpty()) {
            JOptionPane.showMessageDialog(this, "请输入搜索关键词");
            return;
        }
        String[] t = detectTarget();
        setBusy(true, "搜索模组中...");
        new SwingWorker<List<Modrinth.Mod>, Void>() {
            @Override protected List<Modrinth.Mod> doInBackground() throws Exception {
                return Modrinth.search(query, t[0], t[1]);
            }
            @Override protected void done() {
                setBusy(false, "搜索完成");
                try {
                    modModel.clear();
                    List<Modrinth.Mod> res = get();
                    for (Modrinth.Mod m : res) modModel.addElement(m);
                    statusLabel.setText("找到 " + res.size() + " 个模组" + (t[0] == null ? ""
                            : "（匹配 " + t[0] + (t[1] == null ? "" : " / " + t[1]) + "）"));
                } catch (Exception e) {
                    statusLabel.setText("搜索失败: " + e.getMessage());
                }
            }
        }.execute();
    }

    private void onDownloadMod() {
        Modrinth.Mod mod = modList.getSelectedValue();
        if (mod == null) {
            JOptionPane.showMessageDialog(this, "请先在列表中选择一个模组");
            return;
        }
        String[] t = detectTarget();
        Path modsDir = gameDir().resolve("mods");
        VersionInstaller.Progress p = uiProgress();
        setBusy(true, "下载模组 " + mod.title());
        new SwingWorker<String, Void>() {
            @Override protected String doInBackground() {
                try {
                    return Modrinth.download(modsDir, mod, t[0], t[1], p);
                } catch (Exception e) {
                    appendLog("[错误] 模组下载失败: " + e);
                    return null;
                }
            }
            @Override protected void done() {
                try {
                    String file = get();
                    setBusy(false, file != null ? "已下载: " + file : "模组下载失败");
                } catch (Exception ignored) {
                    setBusy(false, "模组下载失败");
                }
            }
        }.execute();
    }

    // ================= 下载 =================

    private void onDownload() {
        VersionManifest.Entry meta = remoteList.getSelectedValue();
        if (meta == null) {
            JOptionPane.showMessageDialog(this, "请先在列表中选择一个版本");
            return;
        }
        Path gd = gameDir();
        Path vd = versionsDir();
        setBusy(true, "准备下载 " + meta.id() + " ...");
        VersionInstaller.Progress p = uiProgress();
        new SwingWorker<Void, Void>() {
            @Override protected Void doInBackground() {
                try {
                    VersionInstaller.install(gd, vd, meta, p);
                } catch (Exception e) {
                    appendLog("[错误] " + e);
                }
                return null;
            }
            @Override protected void done() {
                setBusy(false, "版本 " + meta.id() + " 就绪");
                refreshLocalVersions();
                versionCombo.setSelectedItem(meta.id());
            }
        }.execute();
    }

    // ================= 启动 =================

    private void onLaunch() {
        String versionId = (String) versionCombo.getSelectedItem();
        if (versionId == null) {
            JOptionPane.showMessageDialog(this, "没有可启动的版本，请先在“版本下载”页安装");
            return;
        }
        Account acc;
        try {
            acc = Account.offline(accountField.getText());
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
            return;
        }
        Path gd = gameDir();
        Path vd = versionsDir();
        setBusy(true, "正在检查 " + versionId + " 文件完整性 ...");
        // 先体检：文件不齐就先问要不要自动补齐，避免直接崩在游戏里
        new SwingWorker<List<String>, Void>() {
            @Override protected List<String> doInBackground() throws Exception {
                return VersionInstaller.missingFiles(gd, vd, versionId);
            }
            @Override protected void done() {
                List<String> miss;
                try {
                    miss = get();
                } catch (Exception e) {
                    miss = List.of(); // 检查失败不阻断启动，交给启动本身报错
                }
                if (miss.isEmpty()) {
                    startLaunch(versionId, acc, gd, vd);
                    return;
                }
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < Math.min(6, miss.size()); i++)
                    sb.append("\n  · ").append(miss.get(i));
                if (miss.size() > 6) sb.append("\n  · ... 其余 ").append(miss.size() - 6).append(" 项");
                int r = JOptionPane.showConfirmDialog(MainWindow.this,
                        "检测到 " + miss.size() + " 个文件缺失：" + sb + "\n\n是否立即自动补齐并启动？",
                        "文件不完整", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
                if (r == JOptionPane.YES_OPTION) repairThenLaunch(versionId, acc, gd, vd);
                else setBusy(false, "文件不完整，缺 " + miss.size() + " 项，请重新安装该版本");
            }
        }.execute();
    }

    /** 补齐缺失文件后自动启动 */
    private void repairThenLaunch(String versionId, Account acc, Path gd, Path vd) {
        setBusy(true, "正在补齐 " + versionId + " 缺失文件 ...");
        VersionInstaller.Progress p = uiProgress();
        new SwingWorker<Void, Void>() {
            @Override protected Void doInBackground() throws Exception {
                VersionInstaller.installFromLocalJson(gd, vd, versionId, p);
                return null;
            }
            @Override protected void done() {
                try {
                    get();
                    startLaunch(versionId, acc, gd, vd);
                } catch (Exception e) {
                    Throwable cause = e.getCause() != null ? e.getCause() : e;
                    appendLog("[错误] 补齐文件失败: " + cause);
                    setBusy(false, "补齐文件失败");
                }
            }
        }.execute();
    }

    private void startLaunch(String versionId, Account acc, Path gd, Path vd) {
        setBusy(true, "正在启动 " + versionId + " ...");
        switchTo("log");
        new SwingWorker<Process, Void>() {
            @Override protected Process doInBackground() throws Exception {
                return Launcher.launch(settings, gd, vd, acc, versionId,
                        msg -> SwingUtilities.invokeLater(() -> appendLog(msg)));
            }
            @Override protected void done() {
                try {
                    get();
                    setBusy(false, "游戏已启动（离线模式: " + acc.name + "）");
                } catch (Exception e) {
                    Throwable cause = e.getCause() != null ? e.getCause() : e;
                    appendLog("[错误] 启动失败: " + cause);
                    setBusy(false, "启动失败");
                }
            }
        }.execute();
    }

    // ================= 公共 =================

    private void setBusy(boolean busy, String status) {
        launchButton.setEnabled(!busy);
        downloadButton.setEnabled(!busy);
        if (fabricButton != null) fabricButton.setEnabled(!busy);
        if (modSearchButton != null) modSearchButton.setEnabled(!busy);
        if (modDownloadButton != null) modDownloadButton.setEnabled(!busy);
        statusLabel.setText(status);
        if (!busy) {
            progressBar.setValue(0);
            progressBar.setString("");
        }
    }

    private void appendLog(String line) {
        logArea.append(line + System.lineSeparator());
        logArea.setCaretPosition(logArea.getDocument().getLength());
    }

    private void switchTo(String key) {
        cardLayout.show(cards, key);
        for (NavButton b : navButtons) b.setSelectedState(b.key.equals(key));
    }

    // ================= 自定义控件 =================

    /** 圆角输入框 */
    private static final class RoundTextField extends JTextField {
        RoundTextField(int cols) {
            super(cols);
            setOpaque(false);
            setBackground(new Color(252, 252, 254));
            setBorder(BorderFactory.createEmptyBorder(6, 12, 6, 12));
            setFont(new Font("微软雅黑", Font.PLAIN, 13));
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
            g2.setColor(new Color(0, 0, 0, 45));
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14);
            super.paintComponent(g);
        }
    }

    /** 渐变主按钮 */
    private static final class AccentButton extends JButton {
        AccentButton(String text) {
            super(text);
            setFont(new Font("微软雅黑", Font.BOLD, 13));
            setForeground(Color.WHITE);
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(9, 22, 9, 22));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            if (!isEnabled()) g2.setPaint(new Color(0xB9, 0xBE, 0xCC));
            else if (getModel().isRollover())
                g2.setPaint(new GradientPaint(0, 0, brighter(Icons.ACCENT), getWidth(), getHeight(),
                        brighter(Icons.ACCENT2)));
            else g2.setPaint(new GradientPaint(0, 0, Icons.ACCENT, getWidth(), getHeight(), Icons.ACCENT2));
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
            super.paintComponent(g);
        }
        private static Color brighter(Color c) {
            return new Color(Math.min(255, c.getRed() + 26), Math.min(255, c.getGreen() + 26),
                    Math.min(255, c.getBlue() + 26));
        }
    }

    /** 头部白色药丸按钮 */
    private static final class PillButton extends JButton {
        private boolean accentForeground;

        PillButton(String text) {
            super(text);
            setFont(new Font("微软雅黑", Font.BOLD, 14));
            setForeground(Icons.ACCENT);
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(9, 26, 9, 26));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        }

        void setAccentForeground(boolean accent) {
            this.accentForeground = accent;
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            if (accentForeground && isEnabled()) {
                g2.setPaint(new GradientPaint(0, 0, Color.WHITE, getWidth(), 0,
                        getModel().isRollover() ? new Color(235, 238, 255) : Color.WHITE));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 18, 18);
                setForeground(Icons.ACCENT);
            } else {
                g2.setColor(getModel().isRollover() ? new Color(235, 238, 255) : Color.WHITE);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 18, 18);
            }
            super.paintComponent(g);
        }
    }

    /** 幽灵按钮（细边框，用于"浏览..."） */
    private static final class GhostButton extends JButton {
        GhostButton(String text) {
            super(text);
            setFont(new Font("微软雅黑", Font.PLAIN, 12));
            setForeground(SUBTLE);
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(6, 12, 6, 12));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getModel().isRollover() ? new Color(0xF1, 0xF3, 0xF9) : new Color(0xFA, 0xFB, 0xFD));
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
            g2.setColor(LINE);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 12, 12);
            super.paintComponent(g);
        }
    }

    /** 左侧导航按钮 */
    private final class NavButton extends JButton {
        final String key;
        private boolean selected;

        NavButton(String key, String text) {
            super(text);
            this.key = key;
            setFont(new Font("微软雅黑", Font.PLAIN, 14));
            setHorizontalAlignment(LEFT);
            setIconTextGap(10);
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(12, 22, 12, 12));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
            setAlignmentX(Component.LEFT_ALIGNMENT);
            refreshIcon();
            addActionListener(e -> switchTo(key));
        }

        void setSelectedState(boolean sel) {
            this.selected = sel;
            setFont(new Font("微软雅黑", sel ? Font.BOLD : Font.PLAIN, 14));
            setForeground(sel ? Icons.ACCENT : TEXT);
            refreshIcon();
            repaint();
        }

        private void refreshIcon() {
            setIcon(Icons.nav(key, 20, selected ? Icons.ACCENT : SUBTLE));
        }

        @Override protected void paintComponent(Graphics g) {
            if (selected) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0x5B, 0x6C, 0xFF, 0x1E));
                g2.fillRoundRect(10, 3, getWidth() - 20, getHeight() - 6, 12, 12);
                g2.setColor(Icons.ACCENT);
                g2.fillRoundRect(10, getHeight() / 2 - 10, 4, 20, 2, 2);
            }
            super.paintComponent(g);
        }
    }
}
