package qsmcl.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.util.List;

/** 程序化绘制的现代风格图标（零依赖，无需图片资源文件）。 */
public final class Icons {
    private Icons() {}

    // 主题色
    public static final Color ACCENT  = new Color(0x5B, 0x6C, 0xFF); // 靛蓝
    public static final Color ACCENT2 = new Color(0x9A, 0x5B, 0xFF); // 紫罗兰
    public static final Color GRASS   = new Color(0x3F, 0xD1, 0x8B); // 草绿点缀

    /** App Logo：圆角方块 + 靛蓝→紫渐变 + 白色 Q + 草绿小方块（MC 像素感） */
    public static Image logoImage(int size) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        try {
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            double r = size * 0.26;
            g.setPaint(new GradientPaint(0, 0, ACCENT, size, size, ACCENT2));
            g.fill(new RoundRectangle2D.Double(0, 0, size, size, r, r));
            // 顶部高光
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.18f));
            g.setColor(Color.WHITE);
            g.fill(new RoundRectangle2D.Double(0, 0, size, size * 0.52, r, r));
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
            // 字母 Q
            Font f = new Font("微软雅黑", Font.BOLD, (int) (size * 0.58));
            g.setFont(f);
            FontMetrics fm = g.getFontMetrics();
            String q = "Q";
            int tx = (size - fm.stringWidth(q)) / 2;
            int ty = (size - fm.getHeight()) / 2 + fm.getAscent();
            g.setColor(Color.WHITE);
            g.drawString(q, tx, ty);
            // 草绿像素方块（右下角，MC 草方块致敬）
            int dot = Math.max(2, size / 9);
            g.setColor(GRASS);
            g.fillRect(size - dot * 2, size - dot * 2, dot, dot);
        } finally {
            g.dispose();
        }
        return img;
    }

    /** 导航图标（单色线性风格，24x24 坐标系缩放绘制） */
    public static Icon nav(String kind, int size, Color color) {
        return new Icon() {
            @Override public int getIconWidth() { return size; }
            @Override public int getIconHeight() { return size; }
            @Override public void paintIcon(Component c, Graphics g0, int x, int y) {
                Graphics2D g = (Graphics2D) g0.create();
                try {
                    g.translate(x, y);
                    g.scale(size / 24.0, size / 24.0);
                    g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g.setColor(color);
                    g.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                    switch (kind) {
                        case "download" -> { // 下载：向下箭头 + 托盘
                            g.drawLine(12, 4, 12, 14);
                            g.drawPolyline(new int[]{7, 12, 17}, new int[]{10, 15, 10}, 3);
                            g.drawPolyline(new int[]{4, 4, 20, 20}, new int[]{17, 21, 21, 17}, 4);
                        }
                        case "settings" -> { // 设置：三根滑杆
                            for (int i = 0; i < 3; i++) {
                                int yy = 6 + i * 6;
                                g.drawLine(4, yy, 20, yy);
                                g.fillOval(9 + i * 3 - 3, yy - 3, 6, 6);
                            }
                        }
                        case "log" -> { // 日志：文档 + 行
                            g.drawRoundRect(5, 3, 14, 18, 3, 3);
                            g.drawLine(9, 8, 15, 8);
                            g.drawLine(9, 12, 15, 12);
                            g.drawLine(9, 16, 13, 16);
                        }
                        case "mods" -> { // 模组：箱子
                            g.drawRoundRect(4, 7, 16, 13, 3, 3);
                            g.drawLine(4, 11, 20, 11);
                            g.drawRect(11, 9, 2, 4);
                        }
                        default -> { }
                    }
                } finally {
                    g.dispose();
                }
            }
        };
    }

    /** 窗口图标（多尺寸） */
    public static List<Image> windowIcons() {
        return List.of(logoImage(16), logoImage(24), logoImage(32), logoImage(64), logoImage(256));
    }
}
