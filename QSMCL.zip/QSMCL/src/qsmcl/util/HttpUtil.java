package qsmcl.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.util.function.LongConsumer;

/** 手搓的 HTTP 工具：文本获取、带 SHA1 校验的下载、手动跟随重定向。 */
public final class HttpUtil {
    private HttpUtil() {}

    private static HttpURLConnection connect(String urlStr) throws IOException {
        URL url = java.net.URI.create(urlStr).toURL();
        HttpURLConnection c = (HttpURLConnection) (proxyFor(url) == null
                ? url.openConnection()
                : url.openConnection(proxyFor(url)));
        c.setConnectTimeout(15000);
        c.setReadTimeout(60000);
        c.setRequestProperty("User-Agent", "QSMCL/1.0 (Java Minecraft Launcher)");
        return c;
    }

    /**
     * 代理支持：优先 JVM 系统属性，其次环境变量 HTTP_PROXY / HTTPS_PROXY。
     * 挂了加速器或公司代理时能正常联网（对标 PCL/HMCL 的网络设置）。
     */
    private static java.net.Proxy proxyFor(URL url) {
        boolean https = "https".equalsIgnoreCase(url.getProtocol());
        String spec = pick(System.getProperty(https ? "https.proxyHost" : "http.proxyHost"),
                System.getenv(https ? "HTTPS_PROXY" : "HTTP_PROXY"),
                System.getenv(https ? "https_proxy" : "http_proxy"));
        int explicitPort = -1;
        String portProp = System.getProperty(https ? "https.proxyPort" : "http.proxyPort");
        if (portProp != null && portProp.matches("\\d+")) explicitPort = Integer.parseInt(portProp);
        if (spec == null) return null;
        try {
            String s = spec.trim();
            int scheme = s.indexOf("://");
            if (scheme >= 0) s = s.substring(scheme + 3);
            int slash = s.indexOf('/');
            if (slash >= 0) s = s.substring(0, slash);
            int port = explicitPort;
            int colon = s.lastIndexOf(':');
            if (colon >= 0) {
                if (port < 0) port = Integer.parseInt(s.substring(colon + 1));
                s = s.substring(0, colon);
            }
            if (port < 0) port = 80;
            return new java.net.Proxy(java.net.Proxy.Type.HTTP,
                    new java.net.InetSocketAddress(s, port));
        } catch (Exception ignored) {
            return null;
        }
    }

    private static String pick(String... values) {
        for (String v : values) if (v != null && !v.isBlank()) return v;
        return null;
    }

    private static InputStream open(String url) throws IOException {
        return open(url, 0);
    }

    private static InputStream open(String url, int depth) throws IOException {
        if (depth > 5) throw new IOException("重定向次数过多: " + url);
        HttpURLConnection c = connect(url);
        int code = c.getResponseCode();
        if (code >= 300 && code < 400) {
            String loc = c.getHeaderField("Location");
            c.disconnect();
            if (loc == null) throw new IOException("HTTP " + code + " 无重定向地址: " + url);
            return open(loc, depth + 1);
        }
        if (code != 200) {
            c.disconnect();
            throw new IOException("HTTP " + code + " : " + url);
        }
        return c.getInputStream();
    }

    public static String getText(String url) throws IOException {
        try (InputStream in = open(url)) {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    /**
     * 下载文件到 dest（先写临时文件，校验 SHA1 后原子改名）。
     * @param sha1     期望的 SHA1（十六进制），可为 null 跳过校验
     * @param progress 已下载字节数回调（累计值，可为 null）
     */
    public static void download(String url, Path dest, String sha1, LongConsumer progress) throws IOException {
        Files.createDirectories(dest.getParent());
        // 已存在且校验通过则跳过
        if (Files.isRegularFile(dest) && (sha1 == null || sha1.isBlank() || sha1(dest).equalsIgnoreCase(sha1))) {
            if (progress != null) progress.accept(Files.size(dest));
            return;
        }
        Path tmp = dest.resolveSibling(dest.getFileName() + ".qsmcl-dl");
        try (InputStream in = open(url); OutputStream out = Files.newOutputStream(tmp)) {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                if (progress != null) progress.accept(n);
            }
        }
        if (sha1 != null && !sha1.isBlank() && !sha1(tmp).equalsIgnoreCase(sha1)) {
            Files.deleteIfExists(tmp);
            throw new IOException("SHA1 校验失败: " + dest.getFileName());
        }
        Files.move(tmp, dest, StandardCopyOption.REPLACE_EXISTING);
    }

    public static String sha1(Path f) throws IOException {
        try (InputStream in = Files.newInputStream(f)) {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest()) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            throw new IOException("计算 SHA1 失败", e);
        }
    }
}
