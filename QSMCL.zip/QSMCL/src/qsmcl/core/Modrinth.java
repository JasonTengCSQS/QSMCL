package qsmcl.core;

import qsmcl.util.HttpUtil;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Modrinth 模组搜索与下载（api.modrinth.com 官方 API）。 */
public final class Modrinth {
    private Modrinth() {}

    private static final String API = "https://api.modrinth.com/v2";

    /** 搜索结果中的一个模组 */
    public record Mod(String projectId, String title, String author, String description, long downloads) {
        @Override public String toString() { return title; }
    }

    /**
     * 搜索模组。
     * @param gameVersion 目标 MC 版本（null = 不过滤）
     * @param loader     目标加载器，如 "fabric"（null = 不过滤）
     */
    public static List<Mod> search(String query, String gameVersion, String loader) throws IOException {
        StringBuilder facets = new StringBuilder("[[\"project_type:mod\"]");
        if (gameVersion != null && !gameVersion.isBlank())
            facets.append(",[\"versions:").append(gameVersion).append("\"]");
        if (loader != null && !loader.isBlank())
            facets.append(",[\"categories:").append(loader).append("\"]");
        facets.append("]");

        String url = API + "/search?query=" + enc(query)
                + "&facets=" + enc(facets.toString()) + "&limit=20";
        Map<String, Object> root = Rules.parseJson(HttpUtil.getText(url));
        List<Mod> out = new ArrayList<>();
        for (Object o : Rules.list(root.get("hits"))) {
            Map<String, Object> h = Rules.map(o);
            out.add(new Mod(
                    Rules.str(h.get("project_id")),
                    Rules.str(h.get("title")),
                    Rules.str(h.get("author")),
                    Rules.str(h.get("description")),
                    h.get("downloads") instanceof Number n ? n.longValue() : 0L));
        }
        return out;
    }

    /**
     * 下载模组在指定 MC 版本 + 加载器下的最新文件（主文件优先，SHA1 校验）。
     * @return 下载的文件名
     */
    public static String download(Path modsDir, Mod mod, String gameVersion, String loader,
                                  VersionInstaller.Progress p) throws Exception {
        p.stage("查询 " + mod.title() + " 的可用版本");
        StringBuilder url = new StringBuilder(API + "/project/" + enc(mod.projectId()) + "/version");
        List<String> params = new ArrayList<>();
        if (loader != null && !loader.isBlank())
            params.add("loaders=" + enc("[\"" + loader + "\"]"));
        if (gameVersion != null && !gameVersion.isBlank())
            params.add("game_versions=" + enc("[\"" + gameVersion + "\"]"));
        if (!params.isEmpty()) url.append("?").append(String.join("&", params));

        // 注意：该接口返回 JSON 数组（按发布时间倒序）
        List<Object> versions = Rules.list(qsmcl.util.Json.parse(HttpUtil.getText(url.toString())));
        if (versions == null || versions.isEmpty())
            throw new IOException("没有兼容 " + (gameVersion == null ? "?" : gameVersion)
                    + " (" + (loader == null ? "任意加载器" : loader) + ") 的版本文件");

        Map<String, Object> ver = Rules.map(versions.get(0)); // API 默认按发布时间倒序
        Map<String, Object> file = null;
        for (Object o : Rules.list(ver.get("files"))) {
            Map<String, Object> f = Rules.map(o);
            if (Boolean.TRUE.equals(f.get("primary"))) { file = f; break; }
        }
        if (file == null) {
            List<Object> files = Rules.list(ver.get("files"));
            if (files == null || files.isEmpty()) throw new IOException("版本文件列表为空");
            file = Rules.map(files.get(0));
        }

        String filename = Rules.str(file.get("filename"));
        String sha1 = Rules.str(Rules.map(file.get("hashes")) == null ? null
                : Rules.map(file.get("hashes")).get("sha1"));
        p.stage("下载 " + filename);
        Files.createDirectories(modsDir);
        HttpUtil.download(Rules.str(file.get("url")), modsDir.resolve(filename), sha1, null);
        return filename;
    }

    private static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }
}
