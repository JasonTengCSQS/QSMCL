package qsmcl.core;

import qsmcl.util.HttpUtil;
import qsmcl.util.Json;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Mojang 官方版本清单（version_manifest_v2）。 */
public final class VersionManifest {
    public static final String MANIFEST_URL =
            "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";

    /** 一条版本元数据 */
    public record Entry(String id, String type, String url, String sha1, String releaseTime) {
        public boolean isRelease() { return "release".equals(type); }
        public boolean isSnapshot() { return "snapshot".equals(type); }
        @Override public String toString() { return id + (isSnapshot() ? " (快照)" : ""); }
    }

    /** 拉取全部版本（release / snapshot / old_beta / old_alpha） */
    public static List<Entry> fetch() throws IOException {
        Map<String, Object> root = Rules.parseJson(HttpUtil.getText(MANIFEST_URL));
        List<Object> versions = Rules.list(root.get("versions"));
        List<Entry> out = new ArrayList<>();
        if (versions != null) {
            for (Object o : versions) {
                Map<String, Object> v = Rules.map(o);
                out.add(new Entry(
                        Rules.str(v.get("id")),
                        Rules.str(v.get("type")),
                        Rules.str(v.get("url")),
                        Rules.str(v.get("sha1")),
                        Rules.str(v.get("releaseTime"))));
            }
        }
        return out;
    }
}
