package qsmcl.core;

import qsmcl.util.Json;

import java.util.List;
import java.util.Map;

/** Mojang 版本 JSON 里的 rules 规则求值（os / features）。 */
public final class Rules {
    private Rules() {}

    public static final String OS = "windows"; // 目前按 Windows 启动器实现
    public static final String ARCH = System.getProperty("os.arch").contains("64") ? "64" : "32";

    /** 启动时启用的游戏特性 */
    public static Map<String, Boolean> features(int width, int height) {
        return Map.of(
                "is_demo_user", false,
                "has_custom_resolution", width > 0 && height > 0,
                "has_quick_plays_support", false,
                "is_quick_play_singleplayer", false,
                "is_quick_play_multiplayer", false,
                "is_quick_play_realms", false
        );
    }

    /** 规则列表依次求值，最后一条命中的规则的 action 为结果；无规则时默认允许。 */
    public static boolean allowed(List<Object> rules, Map<String, Boolean> features) {
        if (rules == null || rules.isEmpty()) return true;
        boolean allow = false;
        for (Object o : rules) {
            @SuppressWarnings("unchecked")
            Map<String, Object> r = (Map<String, Object>) o;
            if (matches(r, features)) allow = "allow".equals(r.get("action"));
        }
        return allow;
    }

    @SuppressWarnings("unchecked")
    private static boolean matches(Map<String, Object> rule, Map<String, Boolean> features) {
        Object osObj = rule.get("os");
        if (osObj instanceof Map<?, ?> m) {
            Object name = m.get("name");
            if (name != null && !name.toString().equals(OS)) return false;
            Object arch = m.get("arch");
            if (arch != null && !arch.toString().equals(ARCH)) return false;
        }
        Object featObj = rule.get("features");
        if (featObj instanceof Map<?, ?> m) {
            for (Map.Entry<String, Object> e : ((Map<String, Object>) m).entrySet()) {
                boolean want = Boolean.TRUE.equals(e.getValue());
                if (want != features.getOrDefault(e.getKey(), false)) return false;
            }
        }
        return true;
    }

    /** 方便取版本 JSON 字段 */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> map(Object o) {
        return o == null ? null : (Map<String, Object>) o;
    }

    @SuppressWarnings("unchecked")
    public static List<Object> list(Object o) {
        return o == null ? null : (List<Object>) o;
    }

    public static String str(Object o) {
        return o == null ? null : o.toString();
    }

    /**
     * 读取数字。版本 JSON 中 size 等字段可能是 Long（整数）也可能是 Double（带小数点），
     * 序列化格式还可能给字符串，统一在这里兜住，避免强转抛 ClassCastException。
     */
    public static long num(Object o, long def) {
        if (o == null) return def;
        if (o instanceof Number n) return n.longValue();
        try {
            return Long.parseLong(o.toString());
        } catch (NumberFormatException e) {
            try {
                return (long) Double.parseDouble(o.toString());
            } catch (NumberFormatException e2) {
                return def;
            }
        }
    }

    /** 便捷入口：解析 JSON 字符串为对象 */
    public static Map<String, Object> parseJson(String text) {
        return Json.parseObject(text);
    }
}
