package qsmcl.core;

import qsmcl.util.Json;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/**
 * 启动器：拼装 JVM 参数与游戏参数，拉起 Minecraft 进程并转发日志。
 * 同时兼容 arguments（1.13+）与 minecraftArguments（旧版）两种参数格式。
 */
public final class Launcher {
    public static final String LAUNCHER_NAME = "QSMCL";
    public static final String LAUNCHER_VERSION = "1.0";

    private Launcher() {}

    /** 启动游戏。返回进程对象；日志通过 onLog 回调输出。 */
    public static Process launch(Settings s, Path gameDir, Path versionsDir, Account acc, String versionId,
                                 Consumer<String> onLog) throws Exception {
        Path verDir = versionsDir.resolve(versionId);
        Path jsonPath = verDir.resolve(versionId + ".json");
        if (!Files.isRegularFile(jsonPath))
            throw new IOException("版本 " + versionId + " 未安装（缺少版本 JSON）");
        // 解析继承链（Fabric 等派生版本），合并后的 JSON 等效于完整版本
        Map<String, Object> ver = VersionMerger.merge(versionsDir, versionId);
        List<Map<String, Object>> chain = VersionMerger.chain(versionsDir, versionId);

        String mainClass = Rules.str(ver.get("mainClass"));
        if (mainClass == null)
            throw new IOException("版本 JSON 缺少 mainClass，无法启动");

        // ---------- classpath（继承链中各版本的客户端 jar + 合并后的库） ----------
        List<String> cp = new ArrayList<>();
        for (Map<String, Object> v : chain) {
            String vid = Rules.str(v.get("id"));
            if (vid == null) continue;
            Path jar = versionsDir.resolve(vid).resolve(vid + ".jar");
            if (Files.isRegularFile(jar)) cp.add(jar.toString());
        }
        if (cp.isEmpty())
            throw new IOException("客户端 jar 缺失，请先安装/修复版本");
        // 依赖库：与安装器共用解析逻辑（兼容 Mojang / Maven / 新格式 natives）
        cp.addAll(VersionInstaller.libraryClasspath(gameDir, ver, s.width, s.height));

        // ---------- 启动前自检：文件不齐时给出明确中文提示，而不是让游戏崩一半 ----------
        List<String> missing = VersionInstaller.missingFiles(gameDir, versionsDir, versionId);
        if (!missing.isEmpty()) {
            StringBuilder sb = new StringBuilder("游戏文件不完整，缺少 " + missing.size() + " 项，无法启动：");
            for (int i = 0; i < Math.min(6, missing.size()); i++) sb.append("\n  · ").append(missing.get(i));
            if (missing.size() > 6) sb.append("\n  · ...（其余 " + (missing.size() - 6) + " 项省略）");
            sb.append("\n请先在「版本下载」页重新安装该版本补齐文件。");
            throw new IOException(sb.toString());
        }
        // natives 缺失/为空时自动补解压
        VersionInstaller.ensureNatives(gameDir, versionsDir, versionId);

        // ---------- 变量表 ----------
        String assetsId = ver.get("assets") != null ? Rules.str(ver.get("assets"))
                : (Rules.map(ver.get("assetIndex")) != null
                   ? Rules.str(Rules.map(ver.get("assetIndex")).get("id")) : "legacy");
        Map<String, String> tokens = new LinkedHashMap<>();
        tokens.put("auth_player_name", acc.name);
        tokens.put("version_name", versionId);
        tokens.put("game_directory", gameDir.toString());
        tokens.put("assets_root", gameDir.resolve("assets").toString());
        tokens.put("game_assets", gameDir.resolve("assets").resolve("virtual").resolve(assetsId).toString());
        tokens.put("assets_index_name", assetsId);
        tokens.put("auth_uuid", acc.uuid);
        tokens.put("auth_access_token", acc.accessToken);
        tokens.put("auth_session", acc.accessToken);
        tokens.put("user_type", acc.userType);
        tokens.put("version_type", Rules.str(ver.getOrDefault("type", "release")));
        tokens.put("clientid", "0");
        tokens.put("auth_xuid", "0");
        tokens.put("user_properties", "{}");
        tokens.put("launcher_name", LAUNCHER_NAME);
        tokens.put("launcher_version", LAUNCHER_VERSION);
        if (s.width > 0 && s.height > 0) {
            tokens.put("resolution_width", String.valueOf(s.width));
            tokens.put("resolution_height", String.valueOf(s.height));
        }

        List<String> cmd = buildCommand(s, ver, verDir, cp, mainClass, tokens);

        onLog.accept("[QSMCL] 启动命令: " + String.join(" ", cmd));

        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.directory(gameDir.toFile());
        pb.redirectErrorStream(true);
        Process proc = pb.start();

        Thread t = new Thread(() -> {
            try (BufferedReader r = new BufferedReader(
                    new InputStreamReader(proc.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) onLog.accept(line);
            } catch (IOException ignored) {
            }
        }, "qsmcl-game-log");
        t.setDaemon(true);
        t.start();
        return proc;
    }

    /** 拼装 java 命令行（抽出来便于单独校验 classpath，不必真的启动游戏） */
    static List<String> buildCommand(Settings s, Map<String, Object> ver, Path verDir,
                                     List<String> cp, String mainClass,
                                     Map<String, String> tokens) {
        List<String> cmd = new ArrayList<>();
        cmd.add(s.javaExecutable().toString());
        cmd.add("-Xmx" + s.maxMem + "m");
        cmd.add("-Xms" + Math.min(s.minMem, s.maxMem) + "m");
        if (s.extraJvmArgs != null && !s.extraJvmArgs.isBlank())
            for (String a : s.extraJvmArgs.trim().split("\\s+")) cmd.add(a);
        cmd.add("-Djava.library.path=" + verDir.resolve("natives"));
        cmd.add("-Dminecraft.launcher.brand=" + LAUNCHER_NAME);
        cmd.add("-Dminecraft.launcher.version=" + LAUNCHER_VERSION);
        cmd.add("-Dfml.ignoreInvalidMinecraftCertificates=true");
        cmd.add("-Dfml.ignorePatchDiscrepancies=true");
        // 让子进程用 UTF-8 输出，避免中文日志在本机 GBK 下显示为乱码
        cmd.add("-Dstdout.encoding=UTF-8");
        cmd.add("-Dstderr.encoding=UTF-8");
        cmd.add("-cp");
        cmd.add(String.join(File.pathSeparator, cp));
        cmd.add(mainClass);
        cmd.addAll(buildGameArgs(ver, tokens, s));
        return cmd;
    }

    private static List<String> buildGameArgs(Map<String, Object> ver, Map<String, String> tokens,
                                              Settings s) {
        List<String> out = new ArrayList<>();
        Map<String, Object> arguments = Rules.map(ver.get("arguments"));
        if (arguments != null && arguments.get("game") instanceof List<?> gameList) {
            for (Object o : gameList) {
                if (o instanceof String str) {
                    out.add(substitute(str, tokens));
                } else {
                    Map<String, Object> cond = Rules.map(o);
                    if (Rules.allowed(Rules.list(cond.get("rules")), Rules.features(s.width, s.height))) {
                        for (Object v : Rules.list(cond.get("value")))
                            out.add(substitute(String.valueOf(v), tokens));
                    }
                }
            }
        } else {
            String legacy = Rules.str(ver.get("minecraftArguments"));
            if (legacy != null)
                for (String a : legacy.trim().split("\\s+")) out.add(substitute(a, tokens));
            // 1.5 及以下不带 --userType 等，无需处理；老版缺少分辨率参数也无所谓
        }
        // 分辨率（老版 arguments 里可能没有，手动补）
        if (s.width > 0 && s.height > 0 && !out.contains("--width")) {
            out.add("--width");
            out.add(String.valueOf(s.width));
            out.add("--height");
            out.add(String.valueOf(s.height));
        }
        return out;
    }

    private static String substitute(String v, Map<String, String> tokens) {
        if (v.startsWith("${") && v.endsWith("}")) {
            return tokens.getOrDefault(v.substring(2, v.length() - 1), "");
        }
        return v;
    }
}
