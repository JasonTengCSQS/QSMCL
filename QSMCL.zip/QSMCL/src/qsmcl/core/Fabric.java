package qsmcl.core;

import qsmcl.util.HttpUtil;
import qsmcl.util.Json;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Fabric Loader 安装（meta.fabricmc.net 官方 API）。 */
public final class Fabric {
    private Fabric() {}

    public static final String META = "https://meta.fabricmc.net/v2";

    public record Loader(String version, boolean stable) {
        @Override public String toString() { return version + (stable ? "" : " (测试版)"); }
    }

    /** 获取 Fabric Loader 版本列表（最新在前，stable 优先） */
    public static List<Loader> fetchLoaders() throws IOException {
        // 注意：该接口返回的是 JSON 数组而非对象
        List<Object> arr = Rules.list(qsmcl.util.Json.parse(HttpUtil.getText(META + "/versions/loader")));
        List<Loader> out = new ArrayList<>();
        if (arr != null) {
            for (Object o : arr) {
                Map<String, Object> m = Rules.map(o);
                out.add(new Loader(Rules.str(m.get("version")), Boolean.TRUE.equals(m.get("stable"))));
            }
        }
        return out;
    }

    /**
     * 安装 Fabric 版本。生成的派生版本 JSON 带 inheritsFrom 指向原版，
     * 库文件走 Fabric Maven，资源与客户端 jar 复用原版。
     *
     * @param parentMeta 原版在 Mojang 清单中的条目（父版本 JSON 不在本地时用于下载）
     * @return 生成的版本 id，如 "1.21.11-fabric-0.17.3"
     */
    public static String install(Path gameDir, Path versionsDir, String gameVersion, String loaderVersion,
                                 VersionManifest.Entry parentMeta, VersionInstaller.Progress p) throws Exception {
        // 1. 确保父版本 JSON 存在（库/资源/jar 由合并安装统一处理）
        Path parentJson = versionsDir.resolve(gameVersion).resolve(gameVersion + ".json");
        if (!Files.isRegularFile(parentJson)) {
            if (parentMeta == null)
                throw new IOException("版本清单中找不到原版 " + gameVersion + "，无法安装 Fabric");
            p.stage("获取原版信息 " + gameVersion);
            Files.createDirectories(parentJson.getParent());
            Files.writeString(parentJson, HttpUtil.getText(parentMeta.url()), StandardCharsets.UTF_8);
        }

        // 2. 拉取 Fabric 官方 profile JSON 并改写版本 id
        p.stage("获取 Fabric 安装信息 (" + gameVersion + " / " + loaderVersion + ")");
        String profileUrl = META + "/versions/loader/" + gameVersion + "/" + loaderVersion + "/profile/json";
        Map<String, Object> profile = Rules.parseJson(HttpUtil.getText(profileUrl));
        String newId = gameVersion + "-fabric-" + loaderVersion;
        profile.put("id", newId);

        Path verDir = versionsDir.resolve(newId);
        Files.createDirectories(verDir);
        Files.writeString(verDir.resolve(newId + ".json"), Json.write(profile), StandardCharsets.UTF_8);

        // 3. 合并安装（Fabric Maven 库 + 原版库/Natives/资源/客户端 jar）
        VersionInstaller.installFromLocalJson(gameDir, versionsDir, newId, p);
        return newId;
    }
}
