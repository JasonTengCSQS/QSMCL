package qsmcl.core;

import qsmcl.util.HttpUtil;
import qsmcl.util.Json;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * 版本安装器：下载版本 JSON、客户端 jar、依赖库、Natives、资源文件（Assets）。
 * 全部带 SHA1 校验，已存在且校验通过的文件自动跳过（断点续传式重装）。
 */
public final class VersionInstaller {
    private VersionInstaller() {}

    public interface Progress {
        void stage(String name);
        void progress(int done, int total);
        void log(String msg);
    }

    private record Task(String url, Path dest, String sha1, long size) {}

    /**
     * 安装一个官方版本（从 Mojang 清单下载版本 JSON 后走本地安装流程）。
     * @param gameDir     游戏目录（存放 libraries / assets）
     * @param versionsDir 版本存放目录（存放版本 JSON / jar / Natives，可自定义到任意盘）
     */
    public static void install(Path gameDir, Path versionsDir, VersionManifest.Entry meta, Progress p) throws Exception {
        Path verDir = versionsDir.resolve(meta.id());

        // ---------- 版本 JSON ----------
        p.stage("获取版本信息 " + meta.id());
        p.progress(0, 1);
        Path verJson = verDir.resolve(meta.id() + ".json");
        if (!(Files.isRegularFile(verJson)
                && (meta.sha1() == null || meta.sha1().isBlank()
                    || meta.sha1().equalsIgnoreCase(HttpUtil.sha1(verJson))))) {
            Files.createDirectories(verDir);
            Files.writeString(verJson, HttpUtil.getText(meta.url()), StandardCharsets.UTF_8);
        }
        p.progress(1, 1);

        installFromLocalJson(gameDir, versionsDir, meta.id(), p);
    }

    /**
     * 安装本地已存在的版本（自动解析 inheritsFrom 继承链，支持 Fabric 等派生版本）：
     * 整条链的客户端 jar、合并后的依赖库（兼容 Mojang 与 Maven 两种格式）、Natives、资源文件。
     */
    public static void installFromLocalJson(Path gameDir, Path versionsDir, String versionId, Progress p) throws Exception {
        Path verDir = versionsDir.resolve(versionId);
        Map<String, Object> raw = VersionMerger.loadRaw(versionsDir, versionId);
        List<Map<String, Object>> chain = VersionMerger.chain(versionsDir, versionId);
        Map<String, Object> merged = VersionMerger.merge(versionsDir, versionId);

        // ---------- 客户端 jar（整条继承链各自下载自己的 jar） ----------
        p.stage("下载客户端文件");
        int jars = 0;
        for (Map<String, Object> v : chain) {
            String vid = Rules.str(v.get("id"));
            Map<String, Object> client = Rules.map(Rules.map(v.get("downloads")).get("client"));
            if (vid == null || client == null) continue;
            HttpUtil.download(Rules.str(client.get("url")),
                    versionsDir.resolve(vid).resolve(vid + ".jar"),
                    Rules.str(client.get("sha1")), null);
            jars++;
        }
        if (jars == 0) p.log("没有客户端下载信息（继承链中均无）");
        p.progress(1, 1);

        // ---------- 依赖库（合并后） ----------
        List<Task> libTasks = new ArrayList<>();
        List<Task> nativeJars = new ArrayList<>();
        collectLibraries(merged, gameDir, libTasks, nativeJars);

        p.stage("下载依赖库");
        p.progress(0, Math.max(libTasks.size(), 1));
        AtomicInteger err = new AtomicInteger();
        runParallel(libTasks, 8, (task, idx) -> {
            HttpUtil.download(task.url(), task.dest(), task.sha1(), null);
            p.progress(idx + 1, libTasks.size());
        }, e -> {
            err.incrementAndGet();
            p.log("库下载失败: " + e.getMessage());
        });

        // 解压 Natives（到本版本目录）
        Path nativesDir = verDir.resolve("natives");
        p.stage("解压本地库 (Natives)");
        extractNatives(nativeJars, nativesDir);
        p.progress(nativeJars.size(), Math.max(nativeJars.size(), 1));

        // ---------- 资源文件（合并后） ----------
        installAssets(merged, gameDir, p);

        if (err.get() > 0)
            throw new IOException(err.get() + " 个依赖库下载失败，请重试");
    }

    static void collectLibraries(Map<String, Object> ver, Path gameDir,
                                 List<Task> libTasks, List<Task> nativeJars) {
        collectLibraries(ver, gameDir, libTasks, nativeJars, Rules.features(0, 0));
    }

    @SuppressWarnings("unchecked")
    static void collectLibraries(Map<String, Object> ver, Path gameDir,
                                 List<Task> libTasks, List<Task> nativeJars,
                                 Map<String, Boolean> feats) {
        List<Object> libraries = Rules.list(ver.get("libraries"));
        if (libraries == null) return;
        for (Object o : libraries) {
            Map<String, Object> lib = Rules.map(o);
            if (!Rules.allowed(Rules.list(lib.get("rules")), feats)) continue;
            Map<String, Object> downloads = Rules.map(lib.get("downloads"));
            String libName = Rules.str(lib.get("name"));

            if (downloads == null) {
                // Maven 格式（Fabric 等）：{name: "组:artifact:版本", url: "https://maven.../"}
                addMavenLibrary(lib, gameDir, libTasks);
                continue;
            }

            // 新格式（Mojang complianceLevel>=1）：原生库是独立条目，
            // 例如 org.lwjgl:lwjgl-glfw:3.3.1:natives-windows，靠 rules 区分系统。
            String[] parts = libName == null ? new String[0] : libName.split(":");
            if (parts.length >= 4 && parts[3].startsWith("natives-windows") && isThisMachine(parts[3])) {
                Map<String, Object> artifactN = Rules.map(downloads.get("artifact"));
                if (artifactN != null) {
                    Path dest = gameDir.resolve("libraries").resolve(Rules.str(artifactN.get("path")));
                    nativeJars.add(new Task(
                            Rules.str(artifactN.get("url")), dest,
                            Rules.str(artifactN.get("sha1")),
                            Rules.num(artifactN.get("size"), 0)));
                    // 同时留在 classpath 上：LWJGL 自己也支持从 jar 里提取 native，双保险
                    libTasks.add(new Task(
                            Rules.str(artifactN.get("url")), dest,
                            Rules.str(artifactN.get("sha1")),
                            Rules.num(artifactN.get("size"), 0)));
                }
                continue;
            }

            // Mojang 格式：downloads.artifact {url, sha1, path}
            Map<String, Object> artifact = Rules.map(downloads.get("artifact"));
            if (artifact != null) {
                libTasks.add(new Task(
                        Rules.str(artifact.get("url")),
                        gameDir.resolve("libraries").resolve(Rules.str(artifact.get("path"))),
                        Rules.str(artifact.get("sha1")),
                        Rules.num(artifact.get("size"), 0)));
            }

            // 旧格式的 Natives 分类器（1.12 及更早）
            Map<String, Object> natives = Rules.map(lib.get("natives"));
            if (natives != null) {
                String classifier = Rules.str(natives.get("windows"));
                if (classifier != null) {
                    classifier = classifier.replace("${arch}", Rules.ARCH);
                    Map<String, Object> cls = Rules.map(Rules.map(downloads.get("classifiers")).get(classifier));
                    if (cls != null) {
                        nativeJars.add(new Task(
                                Rules.str(cls.get("url")),
                                gameDir.resolve("libraries").resolve(Rules.str(cls.get("path"))),
                                Rules.str(cls.get("sha1")),
                                Rules.num(cls.get("size"), 0)));
                    }
                }
            }
        }
    }

    /** 判断新格式里的 natives 分类器是否适用于当前机器 */
    private static boolean isThisMachine(String classifier) {
        String arch = System.getProperty("os.arch").toLowerCase();
        boolean arm = arch.contains("aarch64") || arch.contains("arm");
        boolean bit64 = arch.contains("64") && !arm;
        boolean clsArm = classifier.contains("arm64");
        boolean clsX86 = classifier.endsWith("-x86");
        if (clsArm != arm) return false;      // arm/非arm 必须匹配
        return !(clsX86 && bit64);            // 64 位机器跳过纯 x86 版本
    }

    /** Maven 坐标 -> 下载任务：g:a:v 转换为 g/a/v/a-v.jar 相对路径，无 SHA1 */
    private static void addMavenLibrary(Map<String, Object> lib, Path gameDir, List<Task> libTasks) {
        String name = Rules.str(lib.get("name"));
        String baseUrl = Rules.str(lib.get("url"));
        if (name == null || baseUrl == null) return;
        String[] parts = name.split(":");
        if (parts.length < 3) return;
        String path = parts[0].replace('.', '/') + "/" + parts[1] + "/" + parts[2]
                + "/" + parts[1] + "-" + parts[2] + ".jar";
        String url = baseUrl.endsWith("/") ? baseUrl : baseUrl + "/";
        libTasks.add(new Task(url + path,
                gameDir.resolve("libraries").resolve(path), null, 0));
    }

    static void extractNatives(List<Task> nativeJars, Path nativesDir) throws IOException {
        // 先清空旧 natives，避免残留损坏文件
        if (Files.isDirectory(nativesDir)) {
            try (var walk = Files.walk(nativesDir)) {
                walk.sorted(java.util.Comparator.reverseOrder()).forEach(f -> f.toFile().delete());
            }
        }
        Files.createDirectories(nativesDir);
        for (Task t : nativeJars) {
            if (!Files.isRegularFile(t.dest())) continue;
            try (ZipInputStream zin = new ZipInputStream(Files.newInputStream(t.dest()))) {
                ZipEntry e;
                while ((e = zin.getNextEntry()) != null) {
                    String name = e.getName();
                    if (e.isDirectory() || name.startsWith("META-INF")
                            || name.endsWith(".sha1") || name.endsWith(".git")) continue;
                    // 扁平化：jar 内可能是 windows/x64/org/lwjgl/glfw/glfw.dll 这类层级，
                    // 取出纯文件名放到 natives 根目录，和老版本 natives 的布局保持一致。
                    String simple = name.substring(name.lastIndexOf('/') + 1);
                    if (simple.isEmpty()) continue;
                    Path out = nativesDir.resolve(simple);
                    if (Files.exists(out)) continue;
                    try (var fout = Files.newOutputStream(out)) {
                        zin.transferTo(fout);
                    }
                }
            }
        }
    }

    static void installAssets(Map<String, Object> ver, Path gameDir, Progress p) throws Exception {
        Map<String, Object> assetIndexInfo = Rules.map(ver.get("assetIndex"));
        String assetsId = ver.get("assets") != null ? Rules.str(ver.get("assets"))
                : (assetIndexInfo != null ? Rules.str(assetIndexInfo.get("id")) : "legacy");
        Path indexes = gameDir.resolve("assets").resolve("indexes");
        Path indexPath = indexes.resolve(assetsId + ".json");

        if (assetIndexInfo != null) {
            p.stage("下载资源索引 " + assetsId);
            p.progress(0, 1);
            HttpUtil.download(Rules.str(assetIndexInfo.get("url")), indexPath,
                    Rules.str(assetIndexInfo.get("sha1")), null);
            p.progress(1, 1);
        }

        if (!Files.isRegularFile(indexPath)) {
            p.log("没有资源索引（1.6 之前的老版本），跳过资源下载");
            return;
        }

        Map<String, Object> index = Rules.parseJson(Files.readString(indexPath, StandardCharsets.UTF_8));
        Map<String, Object> objects = Rules.map(index.get("objects"));
        if (objects == null || objects.isEmpty()) return;

        boolean virtual = Boolean.TRUE.equals(index.get("virtual"));
        boolean mapToResources = Boolean.TRUE.equals(index.get("map_to_resources"));
        Path objectsDir = gameDir.resolve("assets").resolve("objects");
        Path virtualDir = gameDir.resolve("assets").resolve("virtual").resolve(assetsId);
        Path resourcesDir = gameDir.resolve("resources");

        List<Task> tasks = new ArrayList<>();
        List<String> names = new ArrayList<>();
        for (Map.Entry<String, Object> e : objects.entrySet()) {
            Map<String, Object> obj = Rules.map(e.getValue());
            String hash = Rules.str(obj.get("hash"));
            String url = "https://resources.download.minecraft.net/"
                    + hash.substring(0, 2) + "/" + hash;
            Path dest = objectsDir.resolve(hash.substring(0, 2)).resolve(hash);
            if (Files.isRegularFile(dest)) continue; // 已存在直接跳过
            tasks.add(new Task(url, dest, hash, 0));
            names.add(e.getKey());
        }

        p.stage("下载资源文件 (0/" + tasks.size() + " 已存在)");
        p.progress(0, Math.max(tasks.size(), 1));
        AtomicInteger done = new AtomicInteger();
        runParallel(tasks, 16, (task, idx) -> {
            HttpUtil.download(task.url(), task.dest(), task.sha1(), null);
            int d = done.incrementAndGet();
            p.stage("下载资源文件 (" + d + "/" + tasks.size() + ")");
            p.progress(d, tasks.size());
        }, e -> {
            done.incrementAndGet();
            p.log("资源下载失败: " + e.getMessage());
        });

        // 老版本虚拟资源：复制到游戏目录
        if (virtual || mapToResources) {
            Path target = mapToResources ? resourcesDir : virtualDir;
            p.stage("整理旧版资源 (" + (mapToResources ? "resources" : "virtual") + ")");
            p.progress(0, objects.size());
            int i = 0;
            for (Map.Entry<String, Object> e : objects.entrySet()) {
                Map<String, Object> obj = Rules.map(e.getValue());
                String hash = Rules.str(obj.get("hash"));
                Path src = objectsDir.resolve(hash.substring(0, 2)).resolve(hash);
                Path dst = target.resolve(e.getKey());
                if (Files.isRegularFile(src) && !Files.isRegularFile(dst)) {
                    Files.createDirectories(dst.getParent());
                    Files.copy(src, dst);
                }
                p.progress(++i, objects.size());
            }
        }
    }

    /**
     * 确保 Natives 已解压到版本目录下的 natives 子目录。
     * 缺失或为空时自动重新解压（本地库都是从 libraries 里的 natives jar 抽出来的）。
     */
    public static void ensureNatives(Path gameDir, Path versionsDir, String versionId) throws IOException {
        Path nativesDir = versionsDir.resolve(versionId).resolve("natives");
        if (Files.isDirectory(nativesDir)) {
            try (var s = Files.list(nativesDir)) {
                if (s.findAny().isPresent()) return;
            }
        }
        Map<String, Object> merged = VersionMerger.merge(versionsDir, versionId);
        List<Task> libs = new ArrayList<>();
        List<Task> natives = new ArrayList<>();
        collectLibraries(merged, gameDir, libs, natives);
        if (!natives.isEmpty()) extractNatives(natives, nativesDir);
    }

    /**
     * 体检：检查某版本的文件是否齐全（客户端 jar / 依赖库 / Natives 源 jar / 资源索引）。
     * 返回缺失清单，空列表代表文件齐全。用于启动前自检与"自动修复"。
     */
    public static List<String> missingFiles(Path gameDir, Path versionsDir, String versionId) throws IOException {
        List<String> miss = new ArrayList<>();
        List<Map<String, Object>> chain = VersionMerger.chain(versionsDir, versionId);
        for (Map<String, Object> v : chain) {
            String vid = Rules.str(v.get("id"));
            Map<String, Object> client = Rules.map(Rules.map(v.get("downloads")).get("client"));
            if (vid == null || client == null) continue;
            if (!Files.isRegularFile(versionsDir.resolve(vid).resolve(vid + ".jar")))
                miss.add("客户端 jar: " + vid + ".jar");
        }
        Map<String, Object> merged = VersionMerger.merge(versionsDir, versionId);
        List<Task> libTasks = new ArrayList<>();
        List<Task> nativeJars = new ArrayList<>();
        collectLibraries(merged, gameDir, libTasks, nativeJars);
        for (Task t : libTasks)
            if (!Files.isRegularFile(t.dest())) miss.add("依赖库: " + t.dest().getFileName());
        for (Task t : nativeJars)
            if (!Files.isRegularFile(t.dest())) miss.add("本地库(natives): " + t.dest().getFileName());
        Map<String, Object> ai = Rules.map(merged.get("assetIndex"));
        if (ai != null) {
            String aid = merged.get("assets") != null ? Rules.str(merged.get("assets"))
                    : Rules.str(ai.get("id"));
            if (!Files.isRegularFile(gameDir.resolve("assets").resolve("indexes").resolve(aid + ".json")))
                miss.add("资源索引: " + aid + ".json");
        }
        return miss;
    }

    /**
     * 依赖库 classpath：兼容 Mojang artifact 与 Maven 两种格式，只返回磁盘上真实存在的文件。
     * 启动器与安装器共用同一套解析逻辑，避免两边不一致导致游戏缺类。
     */
    public static List<String> libraryClasspath(Path gameDir, Map<String, Object> merged,
                                                int width, int height) {
        List<Task> libs = new ArrayList<>();
        List<Task> natives = new ArrayList<>();
        collectLibraries(merged, gameDir, libs, natives, Rules.features(width, height));
        List<String> out = new ArrayList<>();
        java.util.LinkedHashSet<String> seen = new java.util.LinkedHashSet<>();
        for (Task t : libs)
            if (Files.isRegularFile(t.dest()) && seen.add(t.dest().toString()))
                out.add(t.dest().toString());
        return out;
    }

    /** 简易并行执行器：出错不中断其他任务，最后汇总 */
    private static void runParallel(List<Task> tasks, int threads, Op op, java.util.function.Consumer<Exception> onError)
            throws InterruptedException {
        if (tasks.isEmpty()) return;
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        AtomicInteger idx = new AtomicInteger();
        for (Task t : tasks) {
            pool.submit(() -> {
                try {
                    op.run(t, idx.getAndIncrement());
                } catch (Exception e) {
                    onError.accept(e);
                }
            });
        }
        pool.shutdown();
        if (!pool.awaitTermination(2, TimeUnit.HOURS))
            throw new InterruptedException("下载超时");
    }

    private interface Op {
        void run(Task t, int idx) throws Exception;
    }
}
