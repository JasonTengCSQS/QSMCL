package qsmcl.core;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

/** 离线（离线模式）账户：正版验证后续可扩展 Microsoft OAuth。 */
public final class Account {
    public final String name;
    public final String uuid;
    public final String accessToken;
    public final String userType;

    private Account(String name, String uuid, String accessToken, String userType) {
        this.name = name;
        this.uuid = uuid;
        this.accessToken = accessToken;
        this.userType = userType;
    }

    public static Account offline(String name) {
        if (name == null || name.isBlank())
            throw new IllegalArgumentException("玩家名不能为空");
        name = name.trim();
        if (!name.matches("[A-Za-z0-9_]{1,16}"))
            throw new IllegalArgumentException("玩家名只能包含字母、数字、下划线，长度 1~16");
        UUID u = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
        return new Account(name, u.toString().replace("-", ""), "0", "legacy");
    }
}
