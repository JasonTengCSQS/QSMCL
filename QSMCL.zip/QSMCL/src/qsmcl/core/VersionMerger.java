package qsmcl.core;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 版本继承链解析与合并。
 * Fabric 等派生版本通过 "inheritsFrom" 指向原版版本，启动/安装时需合并两者：
 * 普通字段子版本覆盖父版本；libraries 与 arguments 各键按"子在前、父在后"拼接。
 */
public final class VersionMerger {
    private VersionMerger() {}

    /** 读取一个版本的原始 JSON */
    public static Map<String, Object> loadRaw(Path versionsDir, String id) throws IOException {
        Path json = versionsDir.resolve(id).resolve(id + ".json");
        if (!Files.isRegularFile(json))
            throw new IOException("版本 " + id + " 未安装（缺少 " + json + "）");
        return Rules.parseJson(Files.readString(json, StandardCharsets.UTF_8));
    }

    /** 继承链：自己 -> 父 -> 祖父 ...（循环引用保护） */
    public static List<Map<String, Object>> chain(Path versionsDir, String id) throws IOException {
        List<Map<String, Object>> chain = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        String cur = id;
        while (cur != null && !cur.isBlank() && seen.add(cur)) {
            Map<String, Object> v = loadRaw(versionsDir, cur);
            chain.add(v);
            cur = Rules.str(v.get("inheritsFrom"));
        }
        if (chain.isEmpty()) throw new IOException("版本 " + id + " 未安装");
        return chain;
    }

    /** 合并整条继承链 */
    public static Map<String, Object> merge(Path versionsDir, String id) throws IOException {
        List<Map<String, Object>> chain = chain(versionsDir, id);
        Map<String, Object> merged = new LinkedHashMap<>(chain.get(chain.size() - 1)); // 最老祖先为底
        for (int i = chain.size() - 2; i >= 0; i--) overlay(merged, chain.get(i));
        return merged;
    }

    @SuppressWarnings("unchecked")
    static void overlay(Map<String, Object> base, Map<String, Object> child) {
        for (Map.Entry<String, Object> e : child.entrySet()) {
            if ("libraries".equals(e.getKey())) {
                List<Object> libs = new ArrayList<>();
                if (e.getValue() instanceof List<?> cl) libs.addAll((List<Object>) cl);
                if (base.get("libraries") instanceof List<?> pl) libs.addAll((List<Object>) pl);
                base.put("libraries", libs);
            } else if ("arguments".equals(e.getKey()) && e.getValue() instanceof Map<?, ?> cm
                    && base.get("arguments") instanceof Map<?, ?> bm) {
                Map<String, Object> b = (Map<String, Object>) bm;
                for (Map.Entry<String, Object> ce : ((Map<String, Object>) cm).entrySet()) {
                    List<Object> mergedList = new ArrayList<>();
                    if (ce.getValue() instanceof List<?> cl) mergedList.addAll((List<Object>) cl);
                    if (b.get(ce.getKey()) instanceof List<?> bl) mergedList.addAll((List<Object>) bl);
                    b.put(ce.getKey(), mergedList);
                }
            } else {
                base.put(e.getKey(), e.getValue());
            }
        }
    }
}
