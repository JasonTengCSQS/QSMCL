package qsmcl.core;

import qsmcl.util.Json;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/** 启动器设置（settings.json，存放在启动器根目录）。 */
public final class Settings {
    public String gameDir = "";        // 游戏目录（.minecraft），空则用 <启动器根>/minecraft
    public String versionsDir = "";    // 版本存放目录，空则用 <游戏目录>/versions（可自定义到任意盘任意文件夹）
    public String javaPath = "";       // Java 可执行文件路径，空则自动找
    public int minMem = 512;           // 最小内存 MB
    public int maxMem = 4096;          // 最大内存 MB
    public int width = 0;              // 窗口宽，0 = 默认
    public int height = 0;             // 窗口高，0 = 默认
    public String extraJvmArgs = "";   // 额外 JVM 参数（空格分隔）
    public String lastAccount = "";    // 上次的玩家名

    private final Path file;

    public Settings(Path file) {
        this.file = file;
        load();
    }

    public void load() {
        try {
            if (Files.isRegularFile(file)) {
                Map<String, Object> m = Rules.parseJson(Files.readString(file, StandardCharsets.UTF_8));
                gameDir = Rules.str(m.getOrDefault("gameDir", ""));
                versionsDir = Rules.str(m.getOrDefault("versionsDir", ""));
                javaPath = Rules.str(m.getOrDefault("javaPath", ""));
                minMem = (int) Rules.num(m.get("minMem"), 512);
                maxMem = (int) Rules.num(m.get("maxMem"), 4096);
                width = (int) Rules.num(m.get("width"), 0);
                height = (int) Rules.num(m.get("height"), 0);
                extraJvmArgs = Rules.str(m.getOrDefault("extraJvmArgs", ""));
                lastAccount = Rules.str(m.getOrDefault("lastAccount", ""));
            }
        } catch (Exception ignored) {
            // 设置文件损坏时使用默认值
        }
    }

    public void save() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("gameDir", gameDir);
        m.put("versionsDir", versionsDir);
        m.put("javaPath", javaPath);
        m.put("minMem", (long) minMem);
        m.put("maxMem", (long) maxMem);
        m.put("width", (long) width);
        m.put("height", (long) height);
        m.put("extraJvmArgs", extraJvmArgs);
        m.put("lastAccount", lastAccount);
        StringBuilder sb = new StringBuilder("{\n");
        int n = m.size(), i = 0;
        for (Map.Entry<String, Object> e : m.entrySet()) {
            sb.append("  \"").append(e.getKey()).append("\": ");
            Object v = e.getValue();
            if (v instanceof Long) sb.append(v);
            else sb.append('"').append(Json.escape(String.valueOf(v))).append('"');
            if (++i < n) sb.append(',');
            sb.append('\n');
        }
        sb.append("}\n");
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(file, sb.toString(), StandardCharsets.UTF_8);
        } catch (Exception ignored) {
        }
    }

    /** 解析后的实际游戏目录 */
    public Path gameDirectory(Path launcherRoot) {
        return (gameDir == null || gameDir.isBlank())
                ? launcherRoot.resolve("minecraft")
                : Path.of(gameDir);
    }

    /** 解析后的版本存放目录（默认游戏目录下的 versions，可自定义到任意盘任意文件夹） */
    public Path versionsDirectory(Path gameDirectory) {
        return (versionsDir == null || versionsDir.isBlank())
                ? gameDirectory.resolve("versions")
                : Path.of(versionsDir);
    }

    /** 解析后的 Java 可执行文件 */
    public Path javaExecutable() {
        if (javaPath != null && !javaPath.isBlank()) return Path.of(javaPath);
        String home = System.getProperty("java.home");
        return Path.of(home, "bin", "java.exe");
    }
}
