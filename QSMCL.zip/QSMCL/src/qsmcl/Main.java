package qsmcl;

import qsmcl.core.Settings;
import qsmcl.ui.MainWindow;

import javax.swing.*;
import java.awt.Font;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * QSMCL —— 手搓 Java 版 Minecraft 启动器（对标 PCL / HMCL）。
 * 纯 JDK 实现，零第三方依赖。
 */
public final class Main {
    public static void main(String[] args) throws Exception {
        // 启动器根目录：优先取运行目录下的 QSMCL 文件夹（兼容从上级目录启动）
        Path cwd = Path.of(System.getProperty("user.dir"));
        Path launcherRoot = Files.isDirectory(cwd.resolve("QSMCL")) ? cwd.resolve("QSMCL") : cwd;

        System.out.println("[QSMCL] 启动器根目录: " + launcherRoot);

        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
            }
            // 统一中文界面字体
            Font font = new Font("微软雅黑", Font.PLAIN, 12);
            UIManager.put("Label.font", font);
            UIManager.put("Button.font", font);
            UIManager.put("TextField.font", font);
            UIManager.put("ComboBox.font", font);
            UIManager.put("List.font", font);
            UIManager.put("TabbedPane.font", font);
            UIManager.put("CheckBox.font", font);
            UIManager.put("Spinner.font", font);

            Settings settings = new Settings(launcherRoot.resolve("settings.json"));
            new MainWindow(launcherRoot, settings).setVisible(true);
        });
    }
}
