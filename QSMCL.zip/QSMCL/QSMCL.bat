@echo off
rem QSMCL launcher startup script
cd /d "%~dp0"
start "" javaw -cp "out/production/QSMCL" qsmcl.Main
